"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth";
import { getErrorMessage } from "@/lib/error";
import { resolveApiOrigin } from "@/lib/runtime-urls";

type ApiErrorLike = {
  response?: {
    status?: number;
  };
};

export default function LoginPage() {
  const router = useRouter();
  const { login, verifyMfa } = useAuth();
  const apiBaseUrl = resolveApiOrigin();
  const googleAuthUrl = `${apiBaseUrl}/api/auth/google`;
  const [form, setForm] = useState({ email: "", password: "" });
  const [challengeId, setChallengeId] = useState("");
  const [mfaCode, setMfaCode] = useState("");
  const [devOtpHint, setDevOtpHint] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const oauthError = params.get("error");
    if (!oauthError) return;

    if (oauthError === "google_account_not_found") {
      setError("No account found for this Google email. Please register first.");
      return;
    }

    if (oauthError === "google_account_inactive") {
      setError("This account is deactivated. Please contact support.");
      return;
    }

    if (oauthError === "google_auth_failed") {
      setError("Google authentication failed. Please try again.");
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      if (challengeId) {
        await verifyMfa(challengeId, mfaCode.trim());
        router.replace("/dashboard/profile");
        return;
      }

      const result = await login(form.email, form.password, rememberMe);
      if (result?.mfaRequired && result.challengeId) {
        setChallengeId(result.challengeId);
        setDevOtpHint(result.devOtp || "");
        return;
      }

      router.replace("/dashboard/profile");
    } catch (err) {
      const status = (err as ApiErrorLike).response?.status;
      const message = getErrorMessage(
        err,
        challengeId ? "Invalid MFA code" : "Invalid email or password",
      );

      if (challengeId && status === 429) {
        setChallengeId("");
        setMfaCode("");
        setDevOtpHint("");
      }

      setError(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen flex items-center justify-center relative">
      {/* Background */}
      <div className="absolute inset-0 bg-glow-radial" />
      <div className="absolute inset-0 bg-grid-pattern bg-grid-40 opacity-30" />

      <div className="relative w-full max-w-md px-4">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-cyber-green/20 border border-cyber-green/30 flex items-center justify-center">
              <svg
                className="w-6 h-6 text-cyber-green"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M22 12H18L15 21L9 3L6 12H2" />
              </svg>
            </div>
            <span className="text-2xl font-bold">
              <span className="text-cyber-green">Cloud</span>
              <span className="text-cyber-text">VM</span>
            </span>
          </Link>
        </div>

        {/* Card */}
        <div className="cyber-card">
          <h2 className="text-2xl font-bold text-cyber-text mb-2">
            {challengeId ? "Admin verification" : "Welcome back"}
          </h2>
          <p className="text-cyber-text-dim text-sm mb-6">
            {challengeId
              ? "Enter your 6-digit MFA code to finish sign in"
              : "Sign in to your account"}
          </p>

          {error && (
            <div className="mb-4 px-4 py-3 rounded-lg bg-cyber-red/10 border border-cyber-red/30 text-cyber-red text-sm">
              {error}
            </div>
          )}

          {!challengeId && (
            <div className="mb-6 space-y-4">
              <a
                href={googleAuthUrl}
                className="cyber-btn-secondary w-full flex items-center justify-center gap-2"
              >
                <span className="flex h-5 w-5 items-center justify-center rounded-full border border-cyber-border text-xs font-semibold text-cyber-cyan">
                  G
                </span>
                Continue with Google
              </a>
              <div className="flex items-center gap-3 text-xs text-cyber-text-dim">
                <span className="h-px flex-1 bg-cyber-border/60" />
                <span>or sign in with email</span>
                <span className="h-px flex-1 bg-cyber-border/60" />
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!challengeId ? (
              <>
                <div>
                  <label className="block text-sm font-medium text-cyber-text-dim mb-1.5">
                    Email
                  </label>
                  <input
                    type="email"
                    className="cyber-input"
                    placeholder="you@example.com"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-cyber-text-dim mb-1.5">
                    Password
                  </label>
                  <input
                    type="password"
                    className="cyber-input"
                    placeholder="••••••••"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    required
                  />
                </div>

                <label className="flex items-center gap-2 text-sm text-cyber-text-dim">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(event) => setRememberMe(event.target.checked)}
                    className="w-4 h-4 rounded border-cyber-border bg-cyber-bg"
                  />
                  <span>Remember me on this device</span>
                </label>
              </>
            ) : (
              <>
                <div>
                  <label className="block text-sm font-medium text-cyber-text-dim mb-1.5">
                    MFA Code
                  </label>
                  <input
                    type="text"
                    className="cyber-input tracking-[0.35em] text-center"
                    placeholder="123456"
                    value={mfaCode}
                    onChange={(e) =>
                      setMfaCode(e.target.value.replace(/[^\d]/g, "").slice(0, 6))
                    }
                    inputMode="numeric"
                    pattern="[0-9]{6}"
                    required
                  />
                </div>

                {devOtpHint && (
                  <p className="text-xs text-cyber-yellow">
                    Dev hint (non-production only): code is <span className="font-semibold">{devOtpHint}</span>
                  </p>
                )}
              </>
            )}

            <button
              type="submit"
              disabled={loading}
              className="cyber-btn-primary w-full"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg
                    className="animate-spin w-4 h-4"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                    />
                  </svg>
                  {challengeId ? "Verifying..." : "Signing in..."}
                </span>
              ) : (
                challengeId ? "Verify & Continue" : "Sign In"
              )}
            </button>

            {challengeId && (
              <button
                type="button"
                className="cyber-btn-secondary w-full"
                onClick={() => {
                  setChallengeId("");
                  setMfaCode("");
                  setDevOtpHint("");
                  setError("");
                }}
              >
                Back to password login
              </button>
            )}
          </form>

          <div className="mt-6 text-center">
            <span className="text-cyber-text-dim text-sm">
              Don&apos;t have an account?{" "}
              <Link
                href="/register"
                className="text-cyber-green hover:text-cyber-cyan transition-colors font-medium"
              >
                Sign Up
              </Link>
            </span>
          </div>
        </div>
      </div>
    </main>
  );
}
