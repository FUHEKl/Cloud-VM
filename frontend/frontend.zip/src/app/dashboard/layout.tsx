"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { useAuth } from "@/lib/auth";
import api from "@/lib/api";
import clsx from "clsx";
import AssistantChat from "@/components/assistant/AssistantChat";
import { useVmSocket } from "@/hooks/useVmSocket";
import type { UserProfileDetails } from "@/types";

const navItems = [
  {
    label: "Dashboard",
    href: "/dashboard",
    icon: (
      <svg
        className="w-5 h-5"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <rect x="3" y="3" width="7" height="7" rx="1" />
        <rect x="14" y="3" width="7" height="7" rx="1" />
        <rect x="3" y="14" width="7" height="7" rx="1" />
        <rect x="14" y="14" width="7" height="7" rx="1" />
      </svg>
    ),
  },
  {
    label: "Virtual Machines",
    href: "/dashboard/vms",
    icon: (
      <svg
        className="w-5 h-5"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <rect x="2" y="3" width="20" height="14" rx="2" />
        <path d="M8 21h8M12 17v4" />
      </svg>
    ),
  },
  {
    label: "SSH Keys",
    href: "/dashboard/ssh-keys",
    icon: (
      <svg
        className="w-5 h-5"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4" />
      </svg>
    ),
  },
  {
    label: "Profile",
    href: "/dashboard/profile",
    icon: (
      <svg
        className="w-5 h-5"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
        <circle cx="12" cy="7" r="4" />
      </svg>
    ),
  },
  {
    label: "AI Assistant",
    href: "/dashboard/assistant",
    icon: (
      <svg
        className="w-5 h-5"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <rect x="4" y="5" width="16" height="12" rx="2" />
        <path d="M9 10h6M12 17v3" />
        <circle cx="8" cy="11" r="1" />
        <circle cx="16" cy="11" r="1" />
      </svg>
    ),
  },
  {
    label: "Billing",
    href: "/dashboard/billing",
    icon: (
      <svg
        className="w-5 h-5"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <rect x="2" y="5" width="20" height="14" rx="2" />
        <path d="M2 10h20" />
        <path d="M7 15h3" />
      </svg>
    ),
  },
];

const adminItems = [
  {
    label: "Manage Users",
    href: "/dashboard/admin/users",
    icon: (
      <svg
        className="w-5 h-5"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" />
      </svg>
    ),
  },
  {
    label: "Admin Billing",
    href: "/dashboard/admin/billing",
    icon: (
      <svg
        className="w-5 h-5"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <rect x="2" y="5" width="20" height="14" rx="2" />
        <path d="M2 10h20" />
        <path d="M7 15h3" />
        <path d="M16 14v4M14 16h4" />
      </svg>
    ),
  },
];

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, isLoading, isAuthenticated, fetchUser, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const profileMenuRef = useRef<HTMLDivElement>(null);
  const [profileDetails, setProfileDetails] = useState<UserProfileDetails | null>(null);
  const profileRefreshTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isAssistantRoute = pathname?.startsWith("/dashboard/assistant");

  const loadProfileDetails = useCallback(async (signal?: AbortSignal) => {
    try {
      const { data } = await api.get<UserProfileDetails>("/users/profile-summary", {
        signal,
      });
      setProfileDetails(data);
    } catch (err: unknown) {
      if ((err as { code?: string }).code === "ERR_CANCELED") return;
      // optional widget data
    }
  }, []);

  useEffect(() => {
    if (!user) {
      fetchUser();
    }
  }, [fetchUser, user]);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.replace("/login");
    }
  }, [isLoading, isAuthenticated, router]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (profileMenuRef.current && !profileMenuRef.current.contains(e.target as Node)) {
        setProfileMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (isAssistantRoute && assistantOpen) {
      setAssistantOpen(false);
    }
  }, [isAssistantRoute, assistantOpen]);

  useEffect(() => {
    if (!isAuthenticated) return;
    const controller = new AbortController();
    void loadProfileDetails(controller.signal);
    return () => controller.abort();
  }, [isAuthenticated, loadProfileDetails]);

  useVmSocket((data) => {
    if (!isAuthenticated || !data?.vmId) return;

    if (profileRefreshTimerRef.current) {
      clearTimeout(profileRefreshTimerRef.current);
    }

    profileRefreshTimerRef.current = setTimeout(() => {
      void loadProfileDetails();
      profileRefreshTimerRef.current = null;
    }, 300);
  });

  useEffect(() => {
    return () => {
      if (profileRefreshTimerRef.current) {
        clearTimeout(profileRefreshTimerRef.current);
      }
    };
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <svg
            className="animate-spin w-8 h-8 text-cyber-green"
            viewBox="0 0 24 24"
            fill="none"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
            />
          </svg>
          <span className="text-cyber-text-dim text-sm">Loading...</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) return null;

  const baseNavItems =
    user?.role === "ADMIN"
      ? navItems.filter((item) => item.href !== "/dashboard/billing")
      : navItems;

  const allNavItems =
    user?.role === "ADMIN" ? [...baseNavItems, ...adminItems] : baseNavItems;

  const handleLogout = async () => {
    await logout();
    window.location.assign("/login");
  };

  const subscription = profileDetails?.subscription;
  const formatHourMetric = (hours: number) => {
    if (!Number.isFinite(hours) || hours <= 0) return "0 min";

    const totalMinutes = Math.max(0, Math.round(hours * 60));
    if (totalMinutes < 60) return `${totalMinutes} min`;

    const h = Math.floor(totalMinutes / 60);
    const m = totalMinutes % 60;
    if (m === 0) return `${h} h`;
    return `${h} h ${m} min`;
  };
  const usagePercent =
    subscription && subscription.vmHoursIncluded > 0
      ? Math.min(100, (subscription.vmHoursUsed / subscription.vmHoursIncluded) * 100)
      : 0;

  const usageTone =
    usagePercent >= 90
      ? "bg-cyber-red"
      : usagePercent >= 75
        ? "bg-cyber-orange"
        : "bg-cyber-green";

  return (
    <div className="min-h-screen flex">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={clsx(
          "fixed lg:sticky lg:top-0 lg:h-screen lg:self-start inset-y-0 left-0 z-50 w-64 bg-cyber-card border-r border-cyber-border flex flex-col transition-transform duration-300",
          sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
        )}
      >
        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b border-cyber-border">
          <Link href="/dashboard" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-cyber-green/20 border border-cyber-green/30 flex items-center justify-center">
              <svg
                className="w-5 h-5 text-cyber-green"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M22 12H18L15 21L9 3L6 12H2" />
              </svg>
            </div>
            <span className="text-lg font-bold">
              <span className="text-cyber-green">Cloud</span>
              <span className="text-cyber-text">VM</span>
            </span>
          </Link>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {allNavItems.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setSidebarOpen(false)}
                className={clsx(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                  isActive
                    ? "bg-cyber-green/10 text-cyber-green border border-cyber-green/20"
                    : "text-cyber-text-dim hover:text-cyber-text hover:bg-cyber-border/30",
                )}
              >
                {item.icon}
                {item.label}
              </Link>
            );
          })}
        </nav>

        {/* User section */}
        <div className="p-4 border-t border-cyber-border">
          {subscription && subscription.planId !== "unlimited" && (
            <div className="mb-3 p-2 rounded-lg border border-cyber-border bg-cyber-bg-soft/30">
              <div className="flex items-center justify-between text-[11px] mb-1">
                <span className="text-cyber-text-dim uppercase">{subscription.planId}</span>
                <span className="text-cyber-text">
                  {formatHourMetric(subscription.vmHoursRemaining)} left
                </span>
              </div>
              <div className="h-1.5 rounded-full bg-cyber-border/60 overflow-hidden">
                <div
                  className={`h-full rounded-full ${usageTone}`}
                  style={{ width: `${usagePercent}%` }}
                />
              </div>
            </div>
          )}

        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top header */}
        <header className="h-16 border-b border-cyber-border bg-cyber-card/50 backdrop-blur-sm flex items-center px-4 lg:px-8 gap-4">
          {/* Mobile menu button */}
          <button
            className="lg:hidden text-cyber-text-dim hover:text-cyber-text"
            onClick={() => setSidebarOpen(true)}
          >
            <svg
              className="w-6 h-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>

          <div className="flex-1" />

          {/* User dropdown top-right */}
          <div className="relative" ref={profileMenuRef}>
            <button
              onClick={() => setProfileMenuOpen((prev) => !prev)}
              className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-cyber-border/30 transition-all duration-200 text-left"
            >
              <div className="w-7 h-7 rounded-full bg-cyber-green/20 border border-cyber-green/30 flex items-center justify-center text-cyber-green font-semibold text-xs">
                {user?.firstName?.[0]}{user?.lastName?.[0]}
              </div>
              <span className="text-sm font-medium text-cyber-text">
                {user?.firstName} {user?.lastName}
              </span>
              <svg
                className={`w-4 h-4 text-cyber-text-dim transition-transform duration-200 ${profileMenuOpen ? "rotate-180" : ""}`}
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M6 9l6 6 6-6" />
              </svg>
            </button>

            {profileMenuOpen && (
              <div className="absolute right-0 top-full mt-2 min-w-[220px] rounded-lg border border-cyber-border bg-cyber-card shadow-lg overflow-hidden z-50">
                <Link
                  href="/dashboard/profile"
                  onClick={() => setProfileMenuOpen(false)}
                  className="flex items-center gap-2 px-4 py-2.5 text-sm text-cyber-text-dim hover:text-cyber-text hover:bg-cyber-border/30 transition-all duration-200"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
                    <circle cx="12" cy="7" r="4" />
                  </svg>
                  Settings
                </Link>
                <button
                  onClick={() => { setProfileMenuOpen(false); handleLogout(); }}
                  className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-cyber-text-dim hover:text-cyber-red hover:bg-cyber-red/10 transition-all duration-200"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9" />
                  </svg>
                  Sign Out
                </button>
              </div>
            )}
          </div>

          {/* Role badge */}
          {user?.role === "ADMIN" && (
            <span className="cyber-badge-orange">Admin</span>
          )}
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 lg:p-8 overflow-auto">{children}</main>

        {/* Floating AI Assistant */}
        {!isAssistantRoute && assistantOpen && (
          <div className="fixed bottom-24 right-4 lg:right-8 z-50 w-[calc(100vw-2rem)] max-w-[420px]">
            <AssistantChat
              mode="compact"
              onClose={() => setAssistantOpen(false)}
            />
          </div>
        )}

        {!isAssistantRoute && (
          <button
            onClick={() => setAssistantOpen((prev) => !prev)}
            className="fixed bottom-6 right-4 lg:right-8 z-50 cyber-btn-primary !px-4 !py-3 shadow-glow inline-flex items-center gap-2"
          >
            <svg
              className="w-4 h-4"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
            >
              <rect x="4" y="5" width="16" height="12" rx="2" />
              <path d="M9 10h6M12 17v3" />
              <circle cx="8" cy="11" r="1" />
              <circle cx="16" cy="11" r="1" />
            </svg>
            <span className="hidden sm:inline">AI Assistant</span>
          </button>
        )}
      </div>
    </div>
  );
}
