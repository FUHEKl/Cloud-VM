"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import api from "@/lib/api";
import { getErrorMessage } from "@/lib/error";
import { useAuth } from "@/lib/auth";
import type { PublicPlanCatalogItem, SubscriptionPlanId, UserProfileDetails } from "@/types";

type PlanId = "student" | "pro" | "enterprise";

interface PaymentRecord {
  id: string;
  amount: number;
  currency: string;
  status: string;
  method?: string | null;
  createdAt: string;
}

export default function BillingPage() {
  const { user } = useAuth();
  const params = useSearchParams();
  const preferredPlan = params.get("plan") as PlanId | null;
  const status = params.get("status");
  const successSessionId = params.get("session_id");
  const isAdmin = user?.role === "ADMIN";

  const [loadingPlan, setLoadingPlan] = useState<PlanId | null>(null);
  const [error, setError] = useState("");
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [loadingPayments, setLoadingPayments] = useState(false);
  const [profileDetails, setProfileDetails] = useState<UserProfileDetails | null>(null);
  const [studentCode, setStudentCode] = useState("");
  const [studentMessage, setStudentMessage] = useState("");
  const [studentBusy, setStudentBusy] = useState(false);
  const [plans, setPlans] = useState<PublicPlanCatalogItem[]>([]);

  const orderedPlans = useMemo(() => {
    if (!preferredPlan) return plans;
    const preferred = plans.find((p) => p.id === preferredPlan);
    if (!preferred) return plans;
    return [preferred, ...plans.filter((p) => p.id !== preferred.id)];
  }, [preferredPlan, plans]);

  const loadPlans = useCallback(async () => {
    try {
      const { data } = await api.get<PublicPlanCatalogItem[]>("/payments/plans");
      if (Array.isArray(data) && data.length > 0) {
        setPlans(data);
      }
    } catch {
      setPlans([]);
    }
  }, []);

  const loadPayments = useCallback(async () => {
    setLoadingPayments(true);
    try {
      const { data } = await api.get<PaymentRecord[]>("/payments/me");
      setPayments(Array.isArray(data) ? data : []);
    } catch (err: unknown) {
      setError(getErrorMessage(err, "Failed to load payment history"));
    } finally {
      setLoadingPayments(false);
    }
  }, []);

  const loadProfileDetails = useCallback(async () => {
    try {
      const { data } = await api.get<UserProfileDetails>("/users/profile-summary");
      setProfileDetails(data);
    } catch {
      // optional panel data
    }
  }, []);

  useEffect(() => {
    void loadPlans();
    void loadPayments();
    void loadProfileDetails();
  }, [loadPlans, loadPayments, loadProfileDetails, status]);

  useEffect(() => {
    if (status !== "success" || !successSessionId || isAdmin) return;

    const confirm = async () => {
      try {
        await api.post("/payments/confirm-session", { sessionId: successSessionId });
        await Promise.all([loadPayments(), loadProfileDetails()]);
      } catch (err: unknown) {
        setError(getErrorMessage(err, "Payment succeeded but plan activation is still processing"));
      }
    };

    void confirm();
  }, [status, successSessionId, isAdmin, loadPayments, loadProfileDetails]);

  const planRank: Record<SubscriptionPlanId, number> = {
    student: 1,
    pro: 2,
    enterprise: 3,
    unlimited: 99,
  };

  const activePlan = profileDetails?.subscription?.planId
    ? (profileDetails.subscription.planId.trim().toLowerCase() as SubscriptionPlanId)
    : undefined;
  const canRenewSamePlan = profileDetails?.subscription?.canRenewSamePlan ?? true;
  const vmUsagePercent = profileDetails?.subscription
    ? Math.min(
        100,
        profileDetails.subscription.vmHoursIncluded > 0
          ? (profileDetails.subscription.vmHoursUsed / profileDetails.subscription.vmHoursIncluded) * 100
          : 0,
      )
    : 0;
  const plansLoading = plans.length === 0;

  const isPlanSelectable = (planId: PlanId) => {
    if (!activePlan || activePlan === "unlimited") return true;

    const requestedRank = planRank[planId];
    const currentRank = planRank[activePlan];

    if (requestedRank > currentRank) return true;
    return canRenewSamePlan;
  };

  const formatDt = (amount: number) =>
    new Intl.NumberFormat("en-US", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    }).format(amount);

  const getDisplayedPlanAmount = (plan: PublicPlanCatalogItem) => {
    if (!activePlan || activePlan === "unlimited") return plan.amountDt;

    const currentPlan = plans.find((p) => p.id === activePlan);
    if (!currentPlan) return plan.amountDt;

    const requestedRank = planRank[plan.id];
    const currentRank = planRank[activePlan];

    if (requestedRank > currentRank) {
      return Math.max(0, Number((plan.amountDt - currentPlan.amountDt).toFixed(2)));
    }

    return plan.amountDt;
  };

  const isUpgradePlan = (planId: PlanId) => {
    if (!activePlan || activePlan === "unlimited") return false;
    return planRank[planId] > planRank[activePlan];
  };

  const formatDecimalHours = (hours: number, alwaysHours = false) => {
    if (alwaysHours) return `${Math.round(hours)} h`;
    if (!Number.isFinite(hours) || hours <= 0) return `0 min`;
    const totalMinutes = Math.round(hours * 60);
    if (totalMinutes < 60) return `${totalMinutes} min`;
    const hh = Math.floor(totalMinutes / 60);
    const mm = totalMinutes % 60;
    const mmStr = mm.toString().padStart(2, "0");
    return `${hh} h ${mmStr} min`;
  };

  const planBlockReason = (planId: PlanId) => {
    if (!activePlan || activePlan === "unlimited") return "";
    const requestedRank = planRank[planId];
    const currentRank = planRank[activePlan];

    if (requestedRank <= currentRank && !canRenewSamePlan) {
      return "Same or lower plan is locked until cycle end or until you reach 90% VM-hours usage.";
    }

    return "";
  };

  useEffect(() => {
    if (status !== "success") return;

    const startedAt = Date.now();
    const interval = setInterval(() => {
      void loadPayments();
      void loadProfileDetails();
      if (Date.now() - startedAt > 20_000) {
        clearInterval(interval);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [status, loadPayments, loadProfileDetails]);

  const formatPaymentMethod = (method?: string | null) => {
    if (!method) return "-";

    const stripeSessionMatch = method.match(/^stripe:([^:]+)(:|$)/i);
    const planMatch = method.match(/:plan:(student|pro|enterprise|unlimited)/i);

    if (stripeSessionMatch) {
      const sessionId = stripeSessionMatch[1] || "";
      const tail = sessionId.length > 8 ? sessionId.slice(-8) : sessionId;
      const planLabel = planMatch?.[1] ? ` · ${planMatch[1].toUpperCase()}` : "";
      return `stripe · session …${tail}${planLabel}`;
    }

    if (method.startsWith("admin:grant:")) {
      const grantedPlan = method.split(":")[2] || "unknown";
      return `admin grant · ${grantedPlan.toUpperCase()}`;
    }

    return method.length > 48 ? `${method.slice(0, 48)}…` : method;
  };

  const sendStudentCode = async () => {
    setStudentMessage("");
    setStudentBusy(true);
    try {
      await api.post("/users/student-verification/request");
      setStudentMessage("Verification code sent to your email.");
    } catch (err: unknown) {
      setStudentMessage(
        (err as { response?: { data?: { message?: string } } })?.response?.data?.message ??
        "Failed to send verification code. Make sure you registered with a student email.",
      );
    } finally {
      setStudentBusy(false);
    }
  };

  const confirmStudentCode = async () => {
    if (!studentCode.trim()) return;
    setStudentMessage("");
    setStudentBusy(true);
    try {
      await api.post("/users/student-verification/confirm", { code: studentCode.trim() });
      setStudentMessage("✓ Student email verified!");
      setStudentCode("");
      await loadProfileDetails();
    } catch (err: unknown) {
      setStudentMessage(
        (err as { response?: { data?: { message?: string } } })?.response?.data?.message ?? "Invalid or expired code.",
      );
    } finally {
      setStudentBusy(false);
    }
  };

  const startCheckout = async (planId: PlanId) => {
    setError("");
    if (isAdmin) {
      setError("Admin accounts are unlimited and cannot create Stripe checkout sessions.");
      return;
    }
    setLoadingPlan(planId);
    try {
      const { data } = await api.post<{ checkoutUrl?: string }>(
        "/payments/checkout-session",
        { planId },
      );

      if (!data?.checkoutUrl) {
        throw new Error("Missing checkout URL");
      }

      window.location.assign(data.checkoutUrl);
    } catch (err: unknown) {
      setError(getErrorMessage(err, "Failed to start Stripe checkout"));
      setLoadingPlan(null);
    }
  };

  return (
    <div className="space-y-6 max-w-6xl">
      <div>
        <h1 className="text-2xl font-bold text-cyber-text mb-2">Billing</h1>
        {/* ✅ Show skeleton while profile is loading */}
        {!profileDetails && !isAdmin && (
          <div className="animate-pulse space-y-3">
            <div className="h-10 bg-cyber-border/30 rounded w-full" />
            <div className="grid md:grid-cols-3 gap-4">
              {[1,2,3].map(i => (
                <div key={i} className="cyber-card h-48 bg-cyber-border/20" />
              ))}
            </div>
          </div>
        )}
        <p className="text-cyber-text-dim">
          Plans are billed in Tunisian dinar (DT). Card payment is processed securely with Stripe.
        </p>
        <p className="text-cyber-text-dim text-sm mt-1">
          Note: Stripe charges your card in USD using the current configured conversion rate.
        </p>
        {isAdmin && (
          <p className="text-cyber-cyan text-sm mt-1">
            Admin account detected: unlimited access is active, billing checkout is disabled.
          </p>
        )}
      </div>

      {status === "success" && (
        <div className="px-4 py-3 rounded-lg bg-cyber-green/10 border border-cyber-green/30 text-cyber-green text-sm">
          Payment completed. Your transaction is being recorded.
        </div>
      )}

      {status === "cancelled" && (
        <div className="px-4 py-3 rounded-lg bg-cyber-orange/10 border border-cyber-orange/30 text-cyber-orange text-sm">
          Checkout cancelled. No charge was made.
        </div>
      )}

      {error && (
        <div className="px-4 py-3 rounded-lg bg-cyber-red/10 border border-cyber-red/30 text-cyber-red text-sm">
          {error}
        </div>
      )}

      {profileDetails?.subscription && !isAdmin && (
        <div className="px-4 py-3 rounded-lg bg-cyber-cyan/10 border border-cyber-cyan/30 text-cyber-text text-sm">
          <span className="font-medium text-cyber-cyan uppercase">{profileDetails.subscription.planId}</span>
          {" "}plan · VM hours used: {formatDecimalHours(profileDetails.subscription.vmHoursUsed)} / {formatDecimalHours(profileDetails.subscription.vmHoursIncluded, true)}
          {" "}· Remaining: {formatDecimalHours(profileDetails.subscription.vmHoursRemaining)}
          {" "}· Cycle ends: {new Date(profileDetails.subscription.cycleEndsAt).toLocaleDateString()}
          <div className="w-full bg-cyber-border rounded h-2 mt-2">
            <div
              className="bg-cyber-cyan h-2 rounded"
              style={{ width: `${vmUsagePercent}%` }}
            />
          </div>
        </div>
      )}

      {!profileDetails?.subscription && !isAdmin && (
        <div className="px-4 py-3 rounded-lg bg-cyber-orange/10 border border-cyber-orange/30 text-cyber-orange text-sm">
          No active subscription yet. Purchase a plan to activate VM quota.
        </div>
      )}

      {!isAdmin && (
        plansLoading ? (
          <div className="grid md:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="cyber-card h-64 animate-pulse bg-cyber-border/20" />
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-4">
            {orderedPlans.map((plan) => {
              const displayedAmount = getDisplayedPlanAmount(plan);
              const upgrade = isUpgradePlan(plan.id);
              const showUpgradePrice = upgrade && displayedAmount < plan.amountDt;

              return (
                <div key={plan.id} className="cyber-card">
                  <h3 className="text-lg font-semibold text-cyber-text mb-1">{plan.name}</h3>
                  {showUpgradePrice ? (
                    <>
                      <p className="text-3xl font-bold text-cyber-green mb-2">
                        Upgrade {formatDt(displayedAmount)} DT
                      </p>
                      <p className="text-xs text-cyber-text-dim mb-3">
                        Full price: {formatDt(plan.amountDt)} DT / month
                      </p>
                    </>
                  ) : (
                    <p className="text-3xl font-bold text-cyber-green mb-4">
                      {formatDt(plan.amountDt)} DT
                      <span className="text-sm text-cyber-text-dim"> / month</span>
                    </p>
                  )}
                  <ul className="space-y-2 mb-5 text-sm text-cyber-text-dim">
                    {plan.features.map((f) => (
                      <li key={f}>• {f}</li>
                    ))}
                  </ul>
                  {upgrade && (
                    <p className="text-xs text-cyber-cyan mb-3">
                      Upgrade price: {formatDt(displayedAmount)} DT (credit applied)
                    </p>
                  )}
                  <button
                    onClick={() => startCheckout(plan.id)}
                    disabled={
                      loadingPlan !== null ||
                      !isPlanSelectable(plan.id) ||
                      (plan.id === "student" && !profileDetails?.studentEmailVerified)
                    }
                    className="cyber-btn-primary w-full disabled:opacity-50"
                  >
                    {loadingPlan === plan.id
                      ? "Opening Stripe..."
                      : upgrade
                        ? `Upgrade for ${formatDt(displayedAmount)} DT`
                        : `Pay ${formatDt(displayedAmount)} DT`}
                  </button>
                  {plan.id === "student" && !profileDetails?.studentEmailVerified && (
                    <div className="mt-3 space-y-2">
                      <p className="text-xs text-cyber-orange">
                        Verify your student email to unlock this plan.
                      </p>
                      <button
                        type="button"
                        onClick={sendStudentCode}
                        disabled={studentBusy}
                        className="cyber-btn-secondary w-full !py-1.5 text-sm disabled:opacity-50"
                      >
                        {studentBusy ? "Sending..." : "Send verification code"}
                      </button>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={studentCode}
                          onChange={(e) => setStudentCode(e.target.value)}
                          placeholder="Enter 6-digit code"
                          maxLength={6}
                          className="flex-1 bg-cyber-bg border border-cyber-border rounded px-3 py-1.5 text-sm text-cyber-text focus:outline-none focus:border-cyber-cyan"
                        />
                        <button
                          type="button"
                          onClick={confirmStudentCode}
                          disabled={studentBusy || !studentCode.trim()}
                          className="cyber-btn-primary !py-1.5 text-sm disabled:opacity-50"
                        >
                          Verify
                        </button>
                      </div>
                      {studentMessage && (
                        <p className={`text-xs mt-1 ${studentMessage.startsWith("✓") ? "text-cyber-green" : "text-cyber-orange"}`}>
                          {studentMessage}
                        </p>
                      )}
                    </div>
                  )}
                  {plan.id === "student" && profileDetails?.studentEmailVerified && (
                    <p className="text-xs text-cyber-green mt-2">✓ Student email verified</p>
                  )}
                  {!isPlanSelectable(plan.id) && (
                    <p className="text-xs text-cyber-orange mt-2">
                      {planBlockReason(plan.id)}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        )
      )}

      <div className="cyber-card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-cyber-text">Payment History</h2>
          <button onClick={loadPayments} className="cyber-btn-secondary !py-2">
            {loadingPayments ? "Refreshing..." : "Refresh"}
          </button>
        </div>

        {payments.length === 0 ? (
          <p className="text-sm text-cyber-text-dim">No payments recorded yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-cyber-text-dim border-b border-cyber-border">
                  <th className="py-2 pr-4">Date</th>
                  <th className="py-2 pr-4">Amount</th>
                  <th className="py-2 pr-4">Status</th>
                  <th className="py-2">Method</th>
                </tr>
              </thead>
              <tbody>
                {payments.map((p) => (
                  <tr key={p.id} className="border-b border-cyber-border/40">
                    <td className="py-2 pr-4 text-cyber-text">{new Date(p.createdAt).toLocaleString()}</td>
                    <td className="py-2 pr-4 text-cyber-text">{p.amount} {p.currency}</td>
                    <td className="py-2 pr-4 text-cyber-text">{p.status}</td>
                    <td className="py-2 text-cyber-text-dim break-all">{formatPaymentMethod(p.method)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}