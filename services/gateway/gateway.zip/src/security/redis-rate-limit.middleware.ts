import { Injectable, NestMiddleware } from "@nestjs/common";
import type { NextFunction, Request, Response } from "express";
import Redis from "ioredis";

interface RateLimitRule {
  name: string;
  method: string;
  path: RegExp;
  limit: number;
  windowSeconds: number;
}

@Injectable()
export class RedisRateLimitMiddleware implements NestMiddleware {
  private readonly redis = new Redis(
    process.env.REDIS_URL ||
      `redis://${process.env.REDIS_HOST || "localhost"}:${process.env.REDIS_PORT || "6379"}`,
    {
      lazyConnect: true,
      maxRetriesPerRequest: 1,
      password: (process.env.REDIS_PASSWORD || "").trim() || undefined,
    },
  );

  private readonly defaultRule: RateLimitRule = {
    name: "default",
    method: "*",
    path: /^\/api\//,
    limit: 60,
    windowSeconds: 60,
  };

  private readonly strictRules: RateLimitRule[] = [
    {
      name: "auth-login",
      method: "POST",
      path: /^\/api\/auth\/login$/,
      limit: 10,
      windowSeconds: 60,
    },
    {
      name: "auth-register",
      method: "POST",
      path: /^\/api\/auth\/register$/,
      limit: 5,
      windowSeconds: 60,
    },
    {
      name: "auth-mfa-verify",
      method: "POST",
      path: /^\/api\/auth\/mfa\/verify$/,
      limit: 8,
      windowSeconds: 60,
    },
    {
      name: "ai-chat",
      method: "POST",
      path: /^\/api\/ai\/chat$/,
      limit: 20,
      windowSeconds: 60,
    },
  ];

  private getClientIp(req: Request): string {
    return (req.ip || req.socket.remoteAddress || "unknown").replace("::ffff:", "");
  }

  private resolveRule(req: Request): RateLimitRule | null {
    const method = req.method.toUpperCase();
    const path = req.path;

    for (const rule of this.strictRules) {
      if (rule.method === method && rule.path.test(path)) {
        return rule;
      }
    }

    if (this.defaultRule.path.test(path)) {
      return this.defaultRule;
    }

    return null;
  }

  async use(req: Request, res: Response, next: NextFunction) {
    const rule = this.resolveRule(req);
    if (!rule) {
      next();
      return;
    }

    const ip = this.getClientIp(req);
    const key = `security:gateway:ratelimit:${rule.name}:${ip}`;

    try {
      if (this.redis.status !== "ready") {
        await this.redis.connect();
      }

      const currentHits = await this.redis.incr(key);
      if (currentHits === 1) {
        await this.redis.expire(key, rule.windowSeconds);
      }

      if (currentHits > rule.limit) {
        const ttl = Math.max(1, await this.redis.ttl(key));

        // SECURITY: explicit Retry-After header for bounded client backoff behavior.
        res.setHeader("Retry-After", String(ttl));

        // SECURITY: structured rate-limit audit log without sensitive payload data.
        console.warn(
          JSON.stringify({
            timestamp: new Date().toISOString(),
            eventType: "rate_limit.hit",
            ip,
            method: req.method,
            path: req.path,
            result: "blocked",
            limit: rule.limit,
            windowSeconds: rule.windowSeconds,
            retryAfterSeconds: ttl,
          }),
        );

        res.status(429).json({
          statusCode: 429,
          message: "Too many requests. Please retry later.",
        });
        return;
      }
    } catch (error) {
      const failOpen = (process.env.RATELIMIT_FAIL_BEHAVIOR || "open").toLowerCase() !== "closed";

      console.warn(
        JSON.stringify({
          timestamp: new Date().toISOString(),
          eventType: "rate_limit.unavailable",
          ip,
          method: req.method,
          path: req.path,
          result: failOpen ? "allowed" : "blocked",
          error: error instanceof Error ? error.message : "unknown",
        }),
      );

      if (!failOpen) {
        res.status(503).json({
          statusCode: 503,
          message: "Rate limiter unavailable. Please retry later.",
        });
        return;
      }
    }

    next();
  }
}
